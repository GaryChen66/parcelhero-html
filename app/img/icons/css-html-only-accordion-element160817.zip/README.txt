A Pen created at CodePen.io. You can find this one at https://codepen.io/abergin/pen/ihlDf.

 Read the copy in the accordion sections for some info about how this was made.